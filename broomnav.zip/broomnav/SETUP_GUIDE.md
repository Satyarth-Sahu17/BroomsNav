# 🚀 Quick Setup Guide for BroomNav

## Getting Started in 5 Minutes

### 1️⃣ Prerequisites Check

Before you begin, make sure you have:

- **Node.js** (v14 or higher) - [Download here](https://nodejs.org/)
- A modern web browser (Chrome, Firefox, Safari, or Edge)
- Internet connection (for map tiles and routing)

To check if Node.js is installed:

```bash
node --version
npm --version
```

### 2️⃣ Installation

**Option A: Using the provided files**

```bash
# Navigate to the broomnav directory
cd broomnav

# Install dependencies
npm install
```

**Option B: Fresh setup**

```bash
# Create a new directory
mkdir broomnav
cd broomnav

# Copy all the provided files into this directory

# Install dependencies
npm install
```

### 3️⃣ Start the Server

```bash
npm start
```

You should see:

```
🎃 BroomNav server is running on http://localhost:3000
```

### 4️⃣ Open in Browser

Open your web browser and go to:

```
http://localhost:3000
```

🎉 **You're all set!**

## 🎮 First-Time Usage

### Testing the App Locally

Since BroomNav needs coordinates to find routes, here are some test locations you can use:

#### New York City Area

**Times Square to Central Park:**

- Start: `40.7580, -73.9855`
- End: `40.7829, -73.9654`

**Brooklyn Bridge to Statue of Liberty:**

- Start: `40.7061, -73.9969`
- End: `40.6892, -74.0445`

#### London Area

**Tower Bridge to Buckingham Palace:**

- Start: `51.5055, -0.0754`
- End: `51.5014, -0.1419`

#### San Francisco Area

**Golden Gate Bridge to Fisherman's Wharf:**

- Start: `37.8199, -122.4783`
- End: `37.8080, -122.4177`

### Using the App

1. **Click the map** or **paste coordinates** in the "Starting Point" field
2. **Click the map** or **paste coordinates** in the "Destination" field
3. **Click "Find Safest Routes"** button
4. View multiple routes ranked by safety score
5. Click on any route to see details

## 🐛 Troubleshooting

### Port Already in Use

If port 3000 is already in use, you can change it:

1. Create a `.env` file:

```bash
echo "PORT=3001" > .env
```

2. Restart the server and visit `http://localhost:3001`

### Cannot Find Routes

- **Issue**: "Failed to fetch routes" error
- **Solution**: Check your internet connection. The app uses external OSRM API for routing.
- **Alternative**: Routes might not be available in very remote areas. Try well-known cities.

### Map Not Loading

- **Issue**: Gray screen where map should be
- **Solution**:
    - Check internet connection
    - Disable browser extensions that might block map tiles
    - Clear browser cache
    - Try a different browser

### Dependencies Installation Failed

- **Issue**: npm install errors
- **Solution**:

```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules
rm -rf node_modules

# Reinstall
npm install
```

## 💡 Tips for Development

### Auto-Reload During Development

Use nodemon for automatic server restart:

```bash
npm run dev
```

### View Server Logs

The console will show:

- Route calculation requests
- Report submissions
- Any errors

### Testing API Directly

You can test the API using curl or Postman:

**Get Routes:**

```bash
curl -X POST http://localhost:3000/api/routes \
  -H "Content-Type: application/json" \
  -d '{"start":{"lat":40.7580,"lng":-73.9855},"end":{"lat":40.7829,"lng":-73.9654}}'
```

**Get Reports:**

```bash
curl http://localhost:3000/api/reports
```

**Submit Report:**

```bash
curl -X POST http://localhost:3000/api/reports \
  -H "Content-Type: application/json" \
  -d '{"lat":40.7580,"lng":-73.9855,"description":"Dark street","type":"lighting"}'
```

## 🔄 Updating the App

If you make changes to files:

1. **Frontend changes** (HTML/CSS/JS in public folder):
    - Just refresh the browser

2. **Backend changes** (server.js):
    - Restart the server (Ctrl+C, then `npm start`)
    - Or use `npm run dev` for auto-restart

## 📱 Mobile Testing

To test on mobile devices on the same network:

1. Find your computer's IP address:
    - **Windows**: `ipconfig` (look for IPv4)
    - **Mac/Linux**: `ifconfig` or `ip addr`

2. On your mobile device, navigate to:
   ```
   http://YOUR_IP_ADDRESS:3000
   ```
   Example: `http://192.168.1.100:3000`

## 🎯 Next Steps

Once everything is running:

1. **Explore the Interface**: Try different routes
2. **Report Unsafe Zones**: Test the reporting feature
3. **Check Community Reports**: View the reports panel
4. **Customize**: Modify colors, themes, or features
5. **Share**: Show it to friends and get feedback

## 📚 Additional Resources

- [Leaflet.js Documentation](https://leafletjs.com/reference.html)
- [Express.js Guide](https://expressjs.com/en/guide/routing.html)
- [OpenStreetMap Wiki](https://wiki.openstreetmap.org/)
- [OSRM Documentation](http://project-osrm.org/)

## 🆘 Still Need Help?

If you're stuck:

1. Check the main README.md for detailed documentation
2. Look at browser console for error messages (F12)
3. Check server terminal for backend errors
4. Verify all files are in the correct structure

---

**Happy navigating! Stay safe and stay spooky! 🎃👻**
