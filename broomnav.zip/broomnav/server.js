const express = require('express');
const cors = require('cors');
const path = require('path');
const axios = require('axios');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Mock safety data (in production, this would come from a database)
let userReports = [];
let safetyData = {
  // Mock lighting data (lat, lng, lighting score 0-100)
  lighting: [],
  // Mock crime data
  crime: [],
  // Mock accident data
  accidents: []
};

// Safety score calculation function
function calculateSafetyScore(lat, lng, userReports) {
  let score = 100; // Start with perfect score
  
  // Check proximity to user-reported spooky zones
  userReports.forEach(report => {
    const distance = calculateDistance(lat, lng, report.lat, report.lng);
    if (distance < 0.5) { // Within 500 meters
      score -= 20 * (1 - distance / 0.5); // Closer = worse
    }
  });
  
  // Add some randomness for demo purposes (simulating real data)
  // In production, this would use real crime, lighting, and accident data
  const randomFactor = Math.random() * 20 - 10; // -10 to +10
  score += randomFactor;
  
  // Simulate time-based safety (night time is less safe)
  const hour = new Date().getHours();
  if (hour >= 22 || hour <= 5) {
    score -= 15; // Night time penalty
  } else if (hour >= 6 && hour <= 18) {
    score += 5; // Daytime bonus
  }
  
  return Math.max(0, Math.min(100, score));
}

// Calculate distance between two coordinates (Haversine formula)
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Radius of Earth in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Analyze route safety
function analyzeRouteSafety(coordinates) {
  let totalScore = 0;
  let segments = [];
  
  coordinates.forEach((coord, index) => {
    const segmentScore = calculateSafetyScore(coord[1], coord[0], userReports);
    totalScore += segmentScore;
    segments.push({
      lat: coord[1],
      lng: coord[0],
      score: segmentScore
    });
  });
  
  const averageScore = totalScore / coordinates.length;
  
  // Determine safety level
  let safetyLevel;
  if (averageScore >= 70) {
    safetyLevel = 'safe';
  } else if (averageScore >= 40) {
    safetyLevel = 'moderate';
  } else {
    safetyLevel = 'risky';
  }
  
  return {
    averageScore: Math.round(averageScore),
    safetyLevel,
    segments
  };
}

// API Routes

// Get routes between two points
app.post('/api/routes', async (req, res) => {
  try {
    const { start, end } = req.body;
    
    if (!start || !end || !start.lat || !start.lng || !end.lat || !end.lng) {
      return res.status(400).json({ error: 'Invalid coordinates' });
    }
    
    // Fetch routes from OpenStreetMap (OSRM - Open Source Routing Machine)
    const osrmUrl = `http://router.project-osrm.org/route/v1/driving/${start.lng},${start.lat};${end.lng},${end.lat}?alternatives=true&steps=true&geometries=geojson`;
    
    const response = await axios.get(osrmUrl);
    
    if (response.data.code !== 'Ok') {
      return res.status(500).json({ error: 'Failed to fetch routes' });
    }
    
    // Process routes and add safety scores
    const routes = response.data.routes.map((route, index) => {
      const safetyAnalysis = analyzeRouteSafety(route.geometry.coordinates);
      
      return {
        id: index,
        geometry: route.geometry,
        distance: route.distance,
        duration: route.duration,
        safetyScore: safetyAnalysis.averageScore,
        safetyLevel: safetyAnalysis.safetyLevel,
        segments: safetyAnalysis.segments
      };
    });
    
    // Sort by safety score (highest first)
    routes.sort((a, b) => b.safetyScore - a.safetyScore);
    
    res.json({ routes });
  } catch (error) {
    console.error('Error fetching routes:', error.message);
    res.status(500).json({ error: 'Failed to fetch routes', details: error.message });
  }
});

// Get user reports
app.get('/api/reports', (req, res) => {
  res.json({ reports: userReports });
});

// Add user report
app.post('/api/reports', (req, res) => {
  try {
    const { lat, lng, description, type } = req.body;
    
    if (!lat || !lng || !description) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
    
    const report = {
      id: Date.now().toString(),
      lat: parseFloat(lat),
      lng: parseFloat(lng),
      description,
      type: type || 'spooky',
      timestamp: new Date().toISOString(),
      upvotes: 0
    };
    
    userReports.push(report);
    res.json({ success: true, report });
  } catch (error) {
    console.error('Error adding report:', error);
    res.status(500).json({ error: 'Failed to add report' });
  }
});

// Delete user report
app.delete('/api/reports/:id', (req, res) => {
  try {
    const { id } = req.params;
    userReports = userReports.filter(report => report.id !== id);
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting report:', error);
    res.status(500).json({ error: 'Failed to delete report' });
  }
});

// Upvote a report
app.post('/api/reports/:id/upvote', (req, res) => {
  try {
    const { id } = req.params;
    const report = userReports.find(r => r.id === id);
    
    if (report) {
      report.upvotes = (report.upvotes || 0) + 1;
      res.json({ success: true, report });
    } else {
      res.status(404).json({ error: 'Report not found' });
    }
  } catch (error) {
    console.error('Error upvoting report:', error);
    res.status(500).json({ error: 'Failed to upvote report' });
  }
});

// Serve the main page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`🎃 BroomNav server is running on http://localhost:${PORT}`);
});
