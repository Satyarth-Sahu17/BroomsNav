// Configuration
const API_BASE_URL = 'http://localhost:3000/api';
const DEFAULT_CENTER = [40.7128, -74.0060]; // New York City default
const DEFAULT_ZOOM = 13;

// Global state
let map;
let routeLayers = [];
let reportMarkers = [];
let currentRoutes = [];
let reportMode = false;
let selectedReportLocation = null;
let startMarker = null;
let endMarker = null;
let selectedRouteIndex = null;

// Color mapping for safety levels
const SAFETY_COLORS = {
    safe: '#3ddc84',
    moderate: '#ffa726',
    risky: '#ef5350'
};

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    initMap();
    initEventListeners();
    loadReports();
});

// Initialize Leaflet map
function initMap() {
    map = L.map('map').setView(DEFAULT_CENTER, DEFAULT_ZOOM);
    
    // Add dark-themed tile layer
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 19
    }).addTo(map);
    
    // Add click handler for map
    map.on('click', handleMapClick);
}

// Initialize event listeners
function initEventListeners() {
    // Current location button
    document.getElementById('current-location-btn').addEventListener('click', getCurrentLocation);
    
    // Find routes button
    document.getElementById('find-routes-btn').addEventListener('click', findRoutes);
    
    // Toggle report mode button
    document.getElementById('toggle-report-mode').addEventListener('click', toggleReportMode);
    
    // Modal close button
    document.getElementById('close-modal').addEventListener('click', closeReportModal);
    
    // Submit report button
    document.getElementById('submit-report-btn').addEventListener('click', submitReport);
    
    // Toggle reports panel
    document.getElementById('toggle-reports-btn').addEventListener('click', toggleReportsPanel);
    
    // Close modal when clicking outside
    document.getElementById('report-modal').addEventListener('click', (e) => {
        if (e.target.id === 'report-modal') {
            closeReportModal();
        }
    });
}

// Get current location
function getCurrentLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                map.setView([latitude, longitude], 15);
                
                // Set start location
                if (startMarker) {
                    map.removeLayer(startMarker);
                }
                startMarker = L.marker([latitude, longitude], {
                    icon: createCustomIcon('📍', '#ff6b35')
                }).addTo(map);
                
                // Reverse geocode to get address (simplified)
                document.getElementById('start-location').value = `${latitude.toFixed(5)}, ${longitude.toFixed(5)}`;
            },
            (error) => {
                showNotification('Unable to get your location', 'error');
                console.error('Geolocation error:', error);
            }
        );
    } else {
        showNotification('Geolocation is not supported by your browser', 'error');
    }
}

// Handle map clicks
function handleMapClick(e) {
    if (reportMode) {
        // Set report location
        selectedReportLocation = e.latlng;
        document.getElementById('report-coords').innerHTML = `
            <small>📍 Location: ${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)}</small>
        `;
        document.getElementById('submit-report-btn').disabled = false;
    } else {
        // Set start or end location
        const startInput = document.getElementById('start-location');
        const endInput = document.getElementById('end-location');
        
        if (!startInput.value) {
            // Set start location
            if (startMarker) map.removeLayer(startMarker);
            startMarker = L.marker([e.latlng.lat, e.latlng.lng], {
                icon: createCustomIcon('📍', '#ff6b35')
            }).addTo(map);
            startInput.value = `${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)}`;
        } else if (!endInput.value) {
            // Set end location
            if (endMarker) map.removeLayer(endMarker);
            endMarker = L.marker([e.latlng.lat, e.latlng.lng], {
                icon: createCustomIcon('🎯', '#6b2fb5')
            }).addTo(map);
            endInput.value = `${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)}`;
        }
    }
}

// Create custom icon
function createCustomIcon(emoji, color) {
    return L.divIcon({
        html: `<div style="font-size: 2rem; text-align: center; filter: drop-shadow(0 0 10px ${color});">${emoji}</div>`,
        className: 'custom-marker',
        iconSize: [40, 40],
        iconAnchor: [20, 40]
    });
}

// Find routes
async function findRoutes() {
    const startInput = document.getElementById('start-location').value;
    const endInput = document.getElementById('end-location').value;
    
    if (!startInput || !endInput) {
        showNotification('Please enter both start and end locations', 'error');
        return;
    }
    
    // Parse coordinates
    const start = parseCoordinates(startInput);
    const end = parseCoordinates(endInput);
    
    if (!start || !end) {
        showNotification('Invalid coordinates. Please use format: lat, lng', 'error');
        return;
    }
    
    // Show loading
    document.getElementById('map-loading').style.display = 'flex';
    
    try {
        const response = await fetch(`${API_BASE_URL}/routes`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ start, end })
        });
        
        if (!response.ok) {
            throw new Error('Failed to fetch routes');
        }
        
        const data = await response.json();
        currentRoutes = data.routes;
        
        // Display routes
        displayRoutes(currentRoutes);
        
        showNotification('Routes found! Select one to view details.', 'success');
    } catch (error) {
        console.error('Error fetching routes:', error);
        showNotification('Failed to find routes. Please try again.', 'error');
    } finally {
        document.getElementById('map-loading').style.display = 'none';
    }
}

// Parse coordinates from input
function parseCoordinates(input) {
    const parts = input.split(',').map(p => p.trim());
    if (parts.length !== 2) return null;
    
    const lat = parseFloat(parts[0]);
    const lng = parseFloat(parts[1]);
    
    if (isNaN(lat) || isNaN(lng)) return null;
    
    return { lat, lng };
}

// Display routes on map and in list
function displayRoutes(routes) {
    // Clear existing route layers
    routeLayers.forEach(layer => map.removeLayer(layer));
    routeLayers = [];
    
    // Show routes section
    document.getElementById('routes-section').style.display = 'block';
    
    // Create route list
    const routesList = document.getElementById('routes-list');
    routesList.innerHTML = '';
    
    routes.forEach((route, index) => {
        // Create route card
        const card = createRouteCard(route, index);
        routesList.appendChild(card);
        
        // Draw route on map
        const coordinates = route.geometry.coordinates.map(coord => [coord[1], coord[0]]);
        
        const routeLayer = L.polyline(coordinates, {
            color: SAFETY_COLORS[route.safetyLevel],
            weight: 5,
            opacity: index === 0 ? 0.8 : 0.4,
            lineJoin: 'round'
        }).addTo(map);
        
        routeLayers.push(routeLayer);
        
        // Add click handler to highlight route
        routeLayer.on('click', () => selectRoute(index));
    });
    
    // Fit map to show all routes
    if (routeLayers.length > 0) {
        const group = L.featureGroup(routeLayers);
        map.fitBounds(group.getBounds().pad(0.1));
    }
    
    // Select first route by default
    selectRoute(0);
}

// Create route card HTML
function createRouteCard(route, index) {
    const card = document.createElement('div');
    card.className = `route-card ${route.safetyLevel}`;
    card.id = `route-card-${index}`;
    
    const distance = (route.distance / 1000).toFixed(2); // Convert to km
    const duration = Math.round(route.duration / 60); // Convert to minutes
    
    card.innerHTML = `
        <div class="route-header">
            <div class="route-title">Route ${index + 1}</div>
            <span class="route-badge ${route.safetyLevel}">${route.safetyLevel}</span>
        </div>
        <div class="route-info">
            <div class="route-info-item">
                <span>📏</span>
                <span>${distance} km</span>
            </div>
            <div class="route-info-item">
                <span>⏱️</span>
                <span>${duration} min</span>
            </div>
        </div>
        <div class="safety-score ${route.safetyLevel}">
            Safety Score: ${route.safetyScore}/100
        </div>
    `;
    
    card.addEventListener('click', () => selectRoute(index));
    
    return card;
}

// Select and highlight a route
function selectRoute(index) {
    selectedRouteIndex = index;
    
    // Update card styles
    document.querySelectorAll('.route-card').forEach((card, i) => {
        if (i === index) {
            card.classList.add('active');
        } else {
            card.classList.remove('active');
        }
    });
    
    // Update route layers
    routeLayers.forEach((layer, i) => {
        if (i === index) {
            layer.setStyle({ opacity: 0.8, weight: 6 });
            layer.bringToFront();
        } else {
            layer.setStyle({ opacity: 0.3, weight: 4 });
        }
    });
    
    // Fit map to selected route
    map.fitBounds(routeLayers[index].getBounds().pad(0.1));
}

// Toggle report mode
function toggleReportMode() {
    reportMode = !reportMode;
    
    if (reportMode) {
        document.getElementById('toggle-report-mode').innerHTML = '<span class="btn-icon">❌</span> Cancel Reporting';
        document.getElementById('report-modal').style.display = 'flex';
        showNotification('Click on the map to mark an unsafe location', 'info');
    } else {
        document.getElementById('toggle-report-mode').innerHTML = '<span class="btn-icon">⚠️</span> Report Unsafe Zone';
        closeReportModal();
    }
}

// Close report modal
function closeReportModal() {
    document.getElementById('report-modal').style.display = 'none';
    document.getElementById('report-description').value = '';
    document.getElementById('report-type').value = 'spooky';
    document.getElementById('report-coords').innerHTML = '<small>Click on the map to select location</small>';
    document.getElementById('submit-report-btn').disabled = true;
    selectedReportLocation = null;
    reportMode = false;
    document.getElementById('toggle-report-mode').innerHTML = '<span class="btn-icon">⚠️</span> Report Unsafe Zone';
}

// Submit report
async function submitReport() {
    if (!selectedReportLocation) {
        showNotification('Please select a location on the map', 'error');
        return;
    }
    
    const description = document.getElementById('report-description').value;
    const type = document.getElementById('report-type').value;
    
    if (!description) {
        showNotification('Please provide a description', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/reports`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                lat: selectedReportLocation.lat,
                lng: selectedReportLocation.lng,
                description,
                type
            })
        });
        
        if (!response.ok) {
            throw new Error('Failed to submit report');
        }
        
        const data = await response.json();
        
        // Add marker to map
        addReportMarker(data.report);
        
        // Reload reports list
        loadReports();
        
        showNotification('Report submitted successfully!', 'success');
        closeReportModal();
    } catch (error) {
        console.error('Error submitting report:', error);
        showNotification('Failed to submit report. Please try again.', 'error');
    }
}

// Load all reports
async function loadReports() {
    try {
        const response = await fetch(`${API_BASE_URL}/reports`);
        if (!response.ok) {
            throw new Error('Failed to load reports');
        }
        
        const data = await response.json();
        
        // Clear existing markers
        reportMarkers.forEach(marker => map.removeLayer(marker));
        reportMarkers = [];
        
        // Add markers for each report
        data.reports.forEach(report => addReportMarker(report));
        
        // Update reports list
        updateReportsList(data.reports);
    } catch (error) {
        console.error('Error loading reports:', error);
    }
}

// Add report marker to map
function addReportMarker(report) {
    const marker = L.marker([report.lat, report.lng], {
        icon: createCustomIcon('👻', '#ef5350')
    }).addTo(map);
    
    marker.bindPopup(`
        <div style="color: #e8e8e8;">
            <h4 style="color: #ff6b35; margin-bottom: 10px;">${getReportTypeEmoji(report.type)} ${getReportTypeLabel(report.type)}</h4>
            <p style="margin-bottom: 8px;">${report.description}</p>
            <small style="color: #b8b8b8;">Reported ${formatTimeAgo(report.timestamp)}</small>
            <div style="margin-top: 10px;">
                <strong>👍 ${report.upvotes || 0}</strong> upvotes
            </div>
        </div>
    `);
    
    reportMarkers.push(marker);
}

// Update reports list in panel
function updateReportsList(reports) {
    const reportsList = document.getElementById('reports-list');
    
    if (reports.length === 0) {
        reportsList.innerHTML = '<div class="empty-reports">No reports yet. Be the first to contribute!</div>';
        return;
    }
    
    reportsList.innerHTML = reports.map(report => `
        <div class="report-item">
            <div class="report-item-header">
                <span class="report-type">${getReportTypeEmoji(report.type)} ${getReportTypeLabel(report.type)}</span>
                <span class="report-time">${formatTimeAgo(report.timestamp)}</span>
            </div>
            <div class="report-description">${report.description}</div>
            <div class="report-actions">
                <button class="report-action-btn" onclick="upvoteReport('${report.id}')">
                    👍 ${report.upvotes || 0}
                </button>
                <button class="report-action-btn" onclick="viewReportOnMap(${report.lat}, ${report.lng})">
                    📍 View
                </button>
            </div>
        </div>
    `).join('');
}

// Upvote a report
async function upvoteReport(reportId) {
    try {
        const response = await fetch(`${API_BASE_URL}/reports/${reportId}/upvote`, {
            method: 'POST'
        });
        
        if (!response.ok) {
            throw new Error('Failed to upvote report');
        }
        
        loadReports();
        showNotification('Thanks for your feedback!', 'success');
    } catch (error) {
        console.error('Error upvoting report:', error);
        showNotification('Failed to upvote report', 'error');
    }
}

// View report on map
function viewReportOnMap(lat, lng) {
    map.setView([lat, lng], 16);
    
    // Find and open the marker popup
    reportMarkers.forEach(marker => {
        const markerLatLng = marker.getLatLng();
        if (markerLatLng.lat === lat && markerLatLng.lng === lng) {
            marker.openPopup();
        }
    });
}

// Toggle reports panel
function toggleReportsPanel() {
    const content = document.getElementById('reports-content');
    const text = document.getElementById('toggle-reports-text');
    
    if (content.classList.contains('collapsed')) {
        content.classList.remove('collapsed');
        text.textContent = 'Hide';
    } else {
        content.classList.add('collapsed');
        text.textContent = 'Show';
    }
}

// Helper functions

function getReportTypeEmoji(type) {
    const emojis = {
        'spooky': '👻',
        'lighting': '💡',
        'crime': '🚨',
        'accident': '⚠️',
        'other': '📝'
    };
    return emojis[type] || '📝';
}

function getReportTypeLabel(type) {
    const labels = {
        'spooky': 'Spooky/Isolated',
        'lighting': 'Poor Lighting',
        'crime': 'Crime Concern',
        'accident': 'Accident-Prone',
        'other': 'Other'
    };
    return labels[type] || 'Other';
}

function formatTimeAgo(timestamp) {
    const now = new Date();
    const date = new Date(timestamp);
    const seconds = Math.floor((now - date) / 1000);
    
    if (seconds < 60) return 'just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
    return date.toLocaleDateString();
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'error' ? '#ef5350' : type === 'success' ? '#3ddc84' : '#6b2fb5'};
        color: white;
        padding: 15px 25px;
        border-radius: 10px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
        z-index: 3000;
        animation: slideInRight 0.3s ease;
        max-width: 300px;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
