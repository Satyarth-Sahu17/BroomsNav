# 🎃 BroomNav: The Safe Route Companion

A spooky-themed, safety-focused navigation web application that helps users find the safest possible
route between two locations, not just the fastest. Perfect for late-night travel and navigating
unfamiliar areas.

![BroomNav](https://img.shields.io/badge/Safety-First-green)
![Version](https://img.shields.io/badge/version-1.0.0-purple)
![License](https://img.shields.io/badge/license-MIT-orange)

## 🌟 Features

### 🛡️ Safety-Based Navigation

- **Smart Route Calculation**: Finds the safest route based on multiple safety parameters
- **Real-time Safety Scoring**: Each route gets a safety score (0-100) based on:
    - User-reported unsafe zones
    - Time of day (night vs. day)
    - Proximity to reported incidents
    - Community feedback

### 🎨 Visual Safety Indicators

- **Color-Coded Routes**:
    - 🟢 **Safe (70-100)**: Well-lit, low-risk areas
    - 🟠 **Moderate (40-69)**: Some risk factors present
    - 🔴 **Risky (0-39)**: High-risk or poorly lit areas

### 👥 Community-Driven Safety

- **User Reporting System**: Report unsafe zones including:
    - 👻 Spooky/Isolated areas
    - 💡 Poor lighting
    - 🚨 Crime concerns
    - ⚠️ Accident-prone zones
- **Real-time Updates**: See community reports instantly
- **Upvote System**: Validate reports with community feedback

### 🎃 Spooky Halloween Theme

- Dark mode interface with ghostly aesthetic
- Smooth animations and transitions
- Engaging yet functional design
- Mobile-responsive layout

## 🚀 Tech Stack

### Frontend

- HTML5, CSS3, JavaScript (ES6+)
- [Leaflet.js](https://leafletjs.com/) - Interactive maps
- [OpenStreetMap](https://www.openstreetmap.org/) - Map data
- Google Fonts (Creepster, Roboto)

### Backend

- Node.js with Express.js
- RESTful API architecture
- [OSRM](http://project-osrm.org/) - Route calculation

### APIs & Data

- OpenStreetMap API for route data
- OSRM routing engine
- In-memory storage (can be extended to Firebase/MongoDB)

## 📦 Installation

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn
- Modern web browser

### Step 1: Clone or Download

```bash
cd broomnav
```

### Step 2: Install Dependencies

```bash
npm install
```

### Step 3: Configure Environment (Optional)

Create a `.env` file based on `.env.example`:

```bash
cp .env.example .env
```

### Step 4: Start the Server

```bash
npm start
```

Or for development with auto-reload:

```bash
npm run dev
```

### Step 5: Open in Browser

Navigate to:

```
http://localhost:3000
```

## 🎮 Usage Guide

### Finding Safe Routes

1. **Set Your Starting Point**:
    - Click the 📍 button to use your current location
    - Or click directly on the map
    - Or enter coordinates manually (format: `lat, lng`)

2. **Set Your Destination**:
    - Click on the map for the end point
    - Or enter coordinates manually

3. **Find Routes**:
    - Click "Find Safest Routes" button
    - View multiple route options ranked by safety

4. **Select a Route**:
    - Click on any route card to highlight it
    - View detailed information:
        - Distance (km)
        - Duration (minutes)
        - Safety Score (0-100)
        - Safety Level (Safe/Moderate/Risky)

### Reporting Unsafe Zones

1. **Enable Report Mode**:
    - Click "Report Unsafe Zone" button

2. **Mark Location**:
    - Click on the map where the unsafe zone is located

3. **Add Details**:
    - Select type of concern (Spooky, Lighting, Crime, etc.)
    - Provide a description
    - Submit the report

4. **View Community Reports**:
    - Check the "Community Reports" panel (bottom-right)
    - Upvote reports you agree with
    - Click "View" to see report location on map

### Understanding Safety Scores

The safety scoring algorithm considers:

- **User Reports** (-20 points per nearby report)
    - Closer reports have more impact
    - Effective range: 500 meters

- **Time of Day**:
    - Night (10 PM - 5 AM): -15 points
    - Day (6 AM - 6 PM): +5 points
    - Evening (6 PM - 10 PM): neutral

- **Base Score**: Starts at 100 (perfect safety)

*Note: In production, this would integrate real crime data, lighting information, and accident
statistics.*

## 🏗️ Project Structure

```
broomnav/
├── public/
│   ├── index.html          # Main HTML file
│   ├── styles.css          # Spooky-themed styling
│   └── app.js              # Frontend JavaScript
├── server.js               # Express.js backend
├── package.json            # Dependencies
├── .env.example            # Environment variables template
└── README.md              # This file
```

## 🔌 API Endpoints

### POST `/api/routes`

Find routes between two points with safety scoring.

**Request Body**:

```json
{
  "start": { "lat": 40.7128, "lng": -74.0060 },
  "end": { "lat": 40.7580, "lng": -73.9855 }
}
```

**Response**:

```json
{
  "routes": [
    {
      "id": 0,
      "geometry": { ... },
      "distance": 5230,
      "duration": 720,
      "safetyScore": 85,
      "safetyLevel": "safe"
    }
  ]
}
```

### GET `/api/reports`

Get all user-submitted safety reports.

### POST `/api/reports`

Submit a new safety report.

**Request Body**:

```json
{
  "lat": 40.7128,
  "lng": -74.0060,
  "description": "Poorly lit area",
  "type": "lighting"
}
```

### POST `/api/reports/:id/upvote`

Upvote a safety report.

### DELETE `/api/reports/:id`

Delete a safety report (admin functionality).

## 🎯 Future Enhancements

### Phase 1: Enhanced Data Integration

- [ ] Integrate real crime statistics APIs
- [ ] Add street lighting data from municipal databases
- [ ] Include accident data from traffic authorities
- [ ] Weather integration for additional context

### Phase 2: Advanced Features

- [ ] User authentication and profiles
- [ ] Save favorite routes
- [ ] Route sharing via links
- [ ] Push notifications for nearby unsafe zones
- [ ] Historical safety data analysis

### Phase 3: Mobile Apps

- [ ] Native Android app
- [ ] Native iOS app
- [ ] Offline map support
- [ ] Background location tracking

### Phase 4: AI & Machine Learning

- [ ] Predictive safety modeling
- [ ] Pattern recognition in incident reports
- [ ] Personalized safety preferences
- [ ] Crowd density estimation

## 🔒 Privacy & Security

- **Location Data**: Not stored permanently, used only for route calculation
- **User Reports**: Anonymous by default
- **No Tracking**: No user behavior tracking or analytics by default
- **Open Source**: Transparent codebase for security auditing

## 🤝 Contributing

We welcome contributions! Here's how:

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

### Contribution Ideas

- Add new safety data sources
- Improve safety scoring algorithm
- Enhance UI/UX design
- Add internationalization (i18n)
- Write unit tests
- Optimize performance

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- [OpenStreetMap](https://www.openstreetmap.org/) for map data
- [Leaflet.js](https://leafletjs.com/) for mapping library
- [OSRM](http://project-osrm.org/) for routing engine
- [CartoDB](https://carto.com/) for dark map tiles
- Halloween emoji creators 🎃👻🧙

## 📞 Support

Having issues? Here's how to get help:

1. Check existing GitHub issues
2. Create a new issue with:
    - Clear description
    - Steps to reproduce
    - Expected vs actual behavior
    - Screenshots (if applicable)

## 🌐 Demo

Try the live demo: [Coming Soon]

## 📊 Browser Support

- ✅ Chrome (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Edge (latest)
- ⚠️ Internet Explorer (not supported)

## 🎨 Screenshots

### Main Interface

*Safety-focused route planning with spooky theme*

### Route Comparison

*Multiple routes color-coded by safety level*

### Community Reports

*User-contributed safety information*

### Report Modal

*Easy reporting of unsafe zones*

---

**Made with 🎃 for safer journeys**

*Navigate safely, travel wisely, stay spooky!*
